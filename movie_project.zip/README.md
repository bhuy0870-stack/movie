1. Giải nén file.
2. Tạo môi trường ảo: python -m venv .venv
3. Kích hoạt môi trường: .\.venv\Scripts\activate
4. Cài thư viện: pip install -r requirements.txt
5. Chạy server: python manage.py runserver 