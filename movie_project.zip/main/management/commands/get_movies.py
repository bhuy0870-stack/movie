from django.core.management.base import BaseCommand
from main.models import Movie
import requests
import time

class Command(BaseCommand):
    help = 'Lấy dữ liệu phim chuyên sâu từ TMDB API (Độ tuổi, Trailer, Cast, Crew)'

    # Cấu hình hằng số
    API_KEY = '640d361bde1790dea88b0c75524307d4'
    BASE_URL = "https://api.themoviedb.org/3"
    GENRE_MAP = {
        28: "Hành động", 12: "Phiêu lưu", 16: "Hoạt hình", 
        35: "Hài", 80: "Tội phạm", 18: "Chính kịch", 
        27: "Kinh dị", 878: "Viễn tưởng", 10749: "Tình cảm",
        9648: "Bí ẩn", 53: "Giật gân", 14: "Fantasy"
    }

    def handle(self, *args, **kwargs):
        if not self.API_KEY or self.API_KEY == 'THE_MOVIEDB_API_KEY_CUA_BAN':
            self.stdout.write(self.style.ERROR('LỖI: Chưa có API Key!'))
            return

        self.stdout.write(self.style.HTTP_INFO('--- Bắt đầu lấy dữ liệu hàng loạt ---'))

        for page in range(1, 11):
            self.fetch_page(page)
            time.sleep(0.5) # Tránh bị TMDB chặn do gọi quá nhanh

        self.stdout.write(self.style.SUCCESS('--- TẤT CẢ DỮ LIỆU ĐÃ ĐƯỢC CẬP NHẬT THÀNH CÔNG ---'))

    def fetch_page(self, page):
        """Lấy danh sách phim theo trang"""
        url = f"{self.BASE_URL}/movie/popular?api_key={self.API_KEY}&language=vi-VN&page={page}"
        try:
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                movies = response.json().get('results', [])
                for item in movies:
                    self.process_movie(item)
                self.stdout.write(f"Đã xử lý xong trang {page}")
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Lỗi tại trang {page}: {e}"))

    def process_movie(self, item):
        """Xử lý chi tiết từng bộ phim"""
        m_id = item['id']
        
        # 1. Lấy thông tin phụ trợ (Trailer, Credits, Certification)
        trailer = self.get_trailer(m_id)
        director, cast = self.get_credits(m_id)
        age_limit = self.get_age_limit(m_id)
        
        # 2. Xử lý ảnh và thể loại
        poster_url = f"https://image.tmdb.org/t/p/w500{item.get('poster_path')}" if item.get('poster_path') else ""
        genre_ids = item.get('genre_ids', [])
        genre_name = self.GENRE_MAP.get(genre_ids[0], "Phim hay") if genre_ids else "Phim hay"

        # 3. Cập nhật Database
        Movie.objects.update_or_create(
            api_id=m_id,
            defaults={
                'title': item['title'],
                'description': item['overview'],
                'release_date': item.get('release_date') or None,
                'poster_url': poster_url,
                'trailer_url': trailer,
                'genres': genre_name,
                'director': director,
                'cast': cast,
                'age_limit': age_limit,
            }
        )

    def get_trailer(self, m_id):
        url = f"{self.BASE_URL}/movie/{m_id}/videos?api_key={self.API_KEY}"
        res = requests.get(url, timeout=5).json()
        for vid in res.get('results', []):
            if vid['site'] == 'YouTube' and vid['type'] == 'Trailer':
                return f"https://www.youtube.com/watch?v={vid['key']}"
        return ""

    def get_credits(self, m_id):
        url = f"{self.BASE_URL}/movie/{m_id}/credits?api_key={self.API_KEY}&language=vi-VN"
        res = requests.get(url, timeout=5).json()
        directors = [m['name'] for m in res.get('crew', []) if m['job'] == 'Director']
        cast = [m['name'] for m in res.get('cast', [])[:5]]
        return ", ".join(directors), ", ".join(cast)

    def get_age_limit(self, m_id):
        url = f"{self.BASE_URL}/movie/{m_id}/release_dates?api_key={self.API_KEY}"
        res = requests.get(url, timeout=5).json()
        for r in res.get('results', []):
            if r['iso_3166_1'] in ['VN', 'US']:
                cert = r['release_dates'][0].get('certification', '')
                mapping = {'18': 18, 'R': 18, 'T18': 18, '16': 16, 'T16': 16, '13': 13, 'PG-13': 13}
                if cert in mapping: return mapping[cert]
                if cert.isdigit(): return int(cert)
        return 0