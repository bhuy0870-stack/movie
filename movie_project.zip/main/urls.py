# main/urls.py

from django.urls import path
from . import views

urlpatterns = [
    # Giao diện chính
    path('', views.home, name='home'), 
    path('movie/<int:movie_id>/', views.movie_detail, name='movie_detail'),

    # Xác thực người dùng
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.profile_view, name='profile'),   
    # Xử lý Review/Bình luận
    path('movie/<int:movie_id>/review/add/', views.add_review, name='add_review'),
    path('review/delete/<int:review_id>/', views.delete_review, name='delete_review'),
]