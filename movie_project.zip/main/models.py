from django.db import models
from django.contrib.auth.models import User

class Movie(models.Model):
    api_id = models.IntegerField(unique=True, null=True, blank=True)
    title = models.CharField(max_length=255)
    description = models.TextField()
    release_date = models.DateField(null=True, blank=True)
    poster_url = models.URLField()
    trailer_url = models.URLField(null=True, blank=True)
    director = models.CharField(max_length=200, blank=True, null=True)
    cast = models.TextField(blank=True, null=True)
    genres = models.CharField(max_length=255, blank=True) 
    age_limit = models.IntegerField(default=0)

    def __str__(self):
        return self.title

class Review(models.Model):
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE, related_name='reviews')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    comment = models.TextField()
    rating = models.IntegerField(default=5)
    created_at = models.DateTimeField(auto_now_add=True)
    sentiment_score = models.FloatField(default=0.0)
    sentiment_label = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return f"{self.user.username} - {self.movie.title}"