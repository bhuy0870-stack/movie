from django.shortcuts import render, get_object_or_404, redirect
from .models import Movie, Review
from django.contrib.auth import login, logout
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.core.paginator import Paginator
from django.contrib import messages
from django.http import HttpResponseForbidden
from datetime import date
import re
import requests

def extract_youtube_id(url):
    if not url: return None
    match = re.search(r'(?<=v=)[\w-]+|(?<=youtu\.be/)[\w-]+', url)
    return match.group(0) if match else None

def home(request):
    search_query = request.GET.get('q', '')
    genre_query = request.GET.get('genre', '')
    movies = Movie.objects.all().order_by('-release_date')
    if search_query:
        movies = movies.filter(Q(title__icontains=search_query) | Q(description__icontains=search_query))
    if genre_query:
        movies = movies.filter(genres__icontains=genre_query)
    paginator = Paginator(movies, 12) 
    movies_page = paginator.get_page(request.GET.get('page'))
    featured_movies = Movie.objects.all().order_by('-release_date')[:5]
    return render(request, 'main/home.html', {
        'movies_page': movies_page, 
        'featured_movies': featured_movies, 
        'search_query': search_query, 
        'genre_query': genre_query
    })

def movie_detail(request, movie_id):
    movie = get_object_or_404(Movie, pk=movie_id)
    reviews = Review.objects.filter(movie=movie).order_by('-created_at')
    
    can_watch_trailer = True
    age_message = ""
    
    if movie.age_limit > 0:
        if not request.user.is_authenticated:
            can_watch_trailer = False
            age_message = "Vui lòng đăng nhập để xác thực độ tuổi."
        else:
            birth_str = request.user.last_name 
            try:
                birth_date = date.fromisoformat(birth_str)
                today = date.today()
                age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
                
                if age < movie.age_limit:
                    can_watch_trailer = False
                    age_message = f"Phim này giới hạn độ tuổi {movie.age_limit}+. Bạn mới {age} tuổi."
            except (ValueError, TypeError):
                can_watch_trailer = False
                age_message = "Thông tin ngày sinh của bạn không hợp lệ hoặc chưa được cập nhật."

    related_by_people = Movie.objects.filter(
        Q(director=movie.director) | 
        Q(cast__icontains=(movie.cast.split(',')[0] if movie.cast else "---"))
    ).exclude(id=movie.id)
    
    first_genre = movie.genres.split(',')[0].strip() if movie.genres else ""
    related_by_genre = Movie.objects.filter(genres__icontains=first_genre).exclude(id__in=related_by_people).exclude(id=movie.id)
    
    recommendations = (list(related_by_people) + list(related_by_genre))[:6]
    youtube_id = extract_youtube_id(movie.trailer_url) if movie.trailer_url else None
    
    context = {
        'movie': movie, 
        'reviews': reviews, 
        'recommendations': recommendations, 
        'youtube_id': youtube_id,
        'can_watch_trailer': can_watch_trailer,
        'age_message': age_message
    }
    return render(request, 'main/detail.html', context)

def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        birth_date = request.POST.get('birth_date')
        if form.is_valid():
            user = form.save(commit=False)
            user.last_name = birth_date 
            user.save()
            login(request, user)
            messages.success(request, "Đăng ký thành công!")
            return redirect('home')
    else: 
        form = UserCreationForm()
    return render(request, 'main/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect(request.POST.get('next', 'home'))
    else: 
        form = AuthenticationForm()
    return render(request, 'main/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('home')

@login_required(login_url='login')
def add_review(request, movie_id):
    if request.method == 'POST':
        movie = get_object_or_404(Movie, pk=movie_id)
        comment = request.POST.get('comment', '').lower()
        rating = int(request.POST.get('rating', 5))
        
        pos_words = ['hay', 'tốt', 'tuyệt', 'đỉnh', 'cuốn', 'thích', 'đáng xem', 'ý nghĩa', 'xuất sắc', 'hấp dẫn', 'ghê', 'xịn', 'mlem']
        neg_words = ['tệ', 'dở', 'chán', 'nhạt', 'phí', 'không hay', 'vớ vẩn', 'kém', 'thất vọng', 'ghét', 'xấu', 'kinh khủng', 'rác']

        score = 0
        for word in pos_words:
            if word in comment: score += 1
        for word in neg_words:
            if word in comment: score -= 1

        if score > 0:
            sentiment_label = "Tích cực 😊"
        elif score < 0:
            sentiment_label = "Tiêu cực 😡"
        else:
            sentiment_label = "Trung lập 😐"

        Review.objects.create(
            user=request.user, 
            movie=movie, 
            comment=request.POST.get('comment'),
            rating=rating, 
            sentiment_label=sentiment_label
        )
        messages.success(request, "Đã gửi bình luận!")
    return redirect('movie_detail', movie_id=movie_id)

@login_required
def delete_review(request, review_id):
    review = get_object_or_404(Review, pk=review_id)
    if review.user == request.user:
        movie_id = review.movie.id
        review.delete()
    return redirect('movie_detail', movie_id=movie_id)

def profile_view(request):
    user = request.user
    user_age = None
    
    if user.last_name:
        try:
            birth_date = date.fromisoformat(user.last_name)
            today = date.today()
            user_age = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
        except ValueError:
            user_age = "Lỗi định dạng"

    return render(request, 'main/profile.html', {'user_age': user_age})